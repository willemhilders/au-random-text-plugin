<?php
/**
 * Plugin Name: Random Text Plugin
 * Plugin URI: https://github.com/willemhilders/au-random-text-plugin
 * Description: Displays random text and supports automatic updates.
 * Version: 0.0.5
 * Author: Willem Hilders
 * Author URI: https://willemhilders.nl
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Display random text using shortcode
 */
function rtp_display_random_text() {
    $texts = array(
        'Hello World!',
        'Hello World again!',
        'WordPress is awesome.',
        'Random text plugin example.',
        'Automatic updates are cool!',
        'Have a great day!'
    );

    return '<p>' . esc_html($texts[array_rand($texts)]) . '</p>';
}
add_shortcode('random_text', 'rtp_display_random_text');

/**
 * GitHub updater
 */
class RTP_GitHub_Updater {

    private $plugin_file;
    private $github_repo;
    private $plugin_data;

    public function __construct($plugin_file, $github_repo) {
        $this->plugin_file = $plugin_file;
        $this->github_repo = $github_repo;

        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_update'));
        add_filter('plugins_api', array($this, 'plugin_info'), 10, 3);
    }

    public function check_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $response = wp_remote_get("https://api.github.com/repos/{$this->github_repo}/releases/latest");

        if (is_wp_error($response)) {
            return $transient;
        }

        $release = json_decode(wp_remote_retrieve_body($response));

        if (version_compare($release->tag_name, $transient->checked[plugin_basename($this->plugin_file)], '>')) {
            $plugin = new stdClass();
            $plugin->slug = plugin_basename($this->plugin_file);
            $plugin->new_version = $release->tag_name;
            $plugin->url = $release->html_url;
            $plugin->package = $release->zipball_url;

            $transient->response[plugin_basename($this->plugin_file)] = $plugin;
        }

        return $transient;
    }

    public function plugin_info($false, $action, $response) {
        if ($action !== 'plugin_information') {
            return false;
        }

        if ($response->slug !== plugin_basename($this->plugin_file)) {
            return false;
        }

        $response = wp_remote_get("https://api.github.com/repos/{$this->github_repo}/releases/latest");

        if (is_wp_error($response)) {
            return false;
        }

        $release = json_decode(wp_remote_retrieve_body($response));

        return (object) array(
            'name' => 'Random Text Plugin',
            'version' => $release->tag_name,
            'author' => 'Willem Hilders',
            'homepage' => $release->html_url,
            'download_link' => $release->zipball_url,
            'sections' => array(
                'description' => 'Displays random text with automatic updates.'
            )
        );
    }
}

/**
 * Initialize updater
 */
new RTP_GitHub_Updater(__FILE__, 'willemhilders/au-random-text-plugin');
